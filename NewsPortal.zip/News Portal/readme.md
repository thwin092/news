# Collecting student contribution management System 


Language(s) to be used: FRONT END: PHP 7.3

RDBMS Software used:    BACK END: MySQL server 5.7.26



step:1 create database username = tpa and password = tpa
step:2 Create database = newsportal
step:3 import sql file from ./newsportal.sql 
step:4 Admin Panel = http://localhost/newsportal/admin 
step:5 User Panel  = http://localhost/newsportal/admin/userlogin.php
step:6 Coordinator Panel =http://localhost/newsportal/admin/coordinatorlogin.php

Username and password are already written in individual report.