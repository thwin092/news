<?php
session_start();
// connect to the database
$conn = mysqli_connect('localhost', 'tpa', 'tpa', 'newsportal');
$sql = "SELECT * FROM tblposts WHERE  Is_Active=1 ";
$result = mysqli_query($conn, $sql);

$files = mysqli_fetch_all($result, MYSQLI_ASSOC);
if(!isset($_SESSION["login"]))
  { 
header('location:index.php');
}
else{
if (isset($_GET['file_id'])) {
    $id = $_GET['file_id'];

    // fetch file to download from database
    $sql = "SELECT * FROM tblposts WHERE  Is_Active=1 and id=$id ";
    $result = mysqli_query($conn, $sql);

    $file = mysqli_fetch_assoc($result);
    $filepath = 'postimages/' . $file['Postfile'];

    if (file_exists($filepath)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename=' . basename($filepath));
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize('postimages/' . $file['Postfile']));
        readfile('postimages/' . $file['Postfile']);

        // Now update downloads count
    }
  }
}