<?php
header('Content-Type: application/json');

$conn = mysqli_connect("localhost","tpa","tpa","newsportal");

$sqlQuery = "SELECT studentname,count(*) as number FROM tbl_marks ORDER BY studentname";

$result = mysqli_query($conn,$sqlQuery);

$data = array();
foreach ($result as $row) {
	$data[] = $row;
}

mysqli_close($conn);

echo json_encode($data);
?>