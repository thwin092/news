<?php
session_start();
// connect to the database
$conn = mysqli_connect('localhost', 'tpa', 'tpa', 'newsportal');
// Uploads files
if(!isset($_SESSION["studentid"]))
  { 
header('location:userlogin.php');
}
else{
if (isset($_POST['save'])) { // if save button on the form is clicked
    $studentname=$_POST['studentname'];
   
   
    // name of the uploaded file
    $filename = $_FILES['myfile']['name'];
    $imgname = $_FILES['img']['name'];
    // destination of the file on the server
    $destination = 'postimages/' . $filename;
    $destination1 = 'postfiles/' . $imgname;
    // get the file extension
    $extension = pathinfo($filename, PATHINFO_EXTENSION);
    $extension1 = pathinfo($imgname, PATHINFO_EXTENSION);
    // the physical file on a temporary uploads directory on the server
    $file = $_FILES['myfile']['tmp_name'];
    $file1 = $_FILES['img']['tmp_name'];
    
    $size = $_FILES['myfile']['size'];

    if (!in_array($extension, ['wmv','pdf','zip','docx'])) {
        echo "You file extension must be .zip, .pdf or .docx";
    } 
    else{
        if (!in_array($extension1, ['jpg','png','gif'])) {
            echo "You file extension must be .zip, .pdf or .docx";
        }
    
    elseif ($_FILES['myfile']['size'] > 10000000) { // file shouldn't be larger than 1Megabyte
        echo "File too large!";
    } else {
        // move the uploaded (temporary) file to the specified destination
        if (move_uploaded_file($file, $destination)) {
            if (move_uploaded_file($file1, $destination1));

            {
            $sql = "INSERT INTO fileupload (name,imgname,studentname, size, downloads) VALUES ('$filename','$imgname','$studentname', $size, 0)";
            if (mysqli_query($conn, $sql)) {
                $msg="File upload successful";
            }
        } 
    }
}
}
}
}
?>