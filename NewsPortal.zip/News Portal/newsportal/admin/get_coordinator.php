<?php
include('includes/config.php');
if(!empty($_POST["catid"])) 
{
 $id=intval($_POST['catid']);
$query=mysqli_query($con,"SELECT * FROM marketingcoordinator WHERE id=$id and status=1");
?>
<option value="">Select Subcategory</option>
<?php
 while($row=mysqli_fetch_array($query))
 {
  ?>
  <option value="<?php echo htmlentities($row['coordinatorid']); ?>"><?php echo htmlentities($row['coordinatorname']); ?></option>
  <?php
 }
}
?>