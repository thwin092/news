<?php
include('includes/config.php');
if(!empty($_POST["catid"])) 
{
 $id=intval($_POST['catid']);
 $query=mysqli_query($con,"SELECT * FROM marketingcoordinator WHERE id=$id ");
?>
<option value="">Select CoordinatorName </option>
<?php
 while($row=mysqli_fetch_array($query))
 {
  ?>
  <option value="<?php echo htmlentities($row['coordinatorid']); ?>"><?php echo htmlentities($row['coordinatorname']); ?></option>
  <?php
 }
}
?>