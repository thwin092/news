<?php 
include('includes/config.php');
session_start();
error_reporting(0);

if(isset($_POST["login1"])){

  date_default_timezone_set("asia/manila");
  $date = date("M-d-Y h:i A",strtotime("+0 HOURS"));
  $studentemail=$_POST['studentemail'];
  $password=($_POST['password']);
// $pass=sha1($pass1);
// $salt="a1Bz20ydqelm8m1nel";
// $pass1=$salt.$pass;




$query=mysqli_query($conn,"SELECT * FROM  student WHERE studentemail = '$studentemail'")or die(mysqli_error($conn));
		$row=mysqli_fetch_array($query);
           $studentid=$row['studentid'];
           $studentemail=$row['studentemail'];

           $_SESSION["studentid"] = $row["studentid"];
		   $_SESSION["studentemail"] = $row["studentemail"];
    
           $counter=mysqli_num_rows($query);
            
		  	if ($counter == 0) 
			  {	
				  echo "<script type='text/javascript'>alert('Invalid Email Address or Password,Please try again!');
				  document.location='../login.html'</script>";
			  } 
			  else
			  {
			  if(password_verify($password, $row["password"]))  
                 {
				  $_SESSION['studentemail']=$studentid;	
			
                        if (!empty($_SERVER["HTTP_CLIENT_IP"]))
							{
							 $ip = $_SERVER["HTTP_CLIENT_IP"];
							}
							elseif (!empty($_SERVER["HTTP_X_FORWARDED_FOR"]))
							{
							 $ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
							}
							else
							{
							 $ip = $_SERVER["REMOTE_ADDR"];
							}

							$host = gethostbyaddr($_SERVER['REMOTE_ADDR']);


                           $remarks="Has LoggedIn the system at";  
                      
                          mysqli_query($conn,"INSERT INTO student_log(studentid,studentemail,action,ip,host,login_time) VALUES('$studentid','$studentemail','$remarks','$ip','$host','$date')")or die(mysqli_error($conn));
                 
			  	echo "<script type='text/javascript'>document.location='../private_user/home.php'</script>";  
		 }
	  }
   }
?>

 
<!DOCTYPE html>
<html lang="en">
<form method="POST">
<div class="input-group">
                          
<input type="text" class="input--style-1" placeholder="Enter Username" required="true" name="studentemail">
</div>

<div class="row row-space">
<div class="col-2">
<div class="input-group">
<input type="password" class="input--style-1" placeholder="Password" name="password" required="true">
</div>
</div>
</div>
                        
<div class="p-t-20">
<button class="btn btn--radius btn--green" type="submit" name="login1">Sign IN</button>
</div><br>
<a href="index.php">Don't have an account ? CREATE AN ACCOUNT</a>
</form>
</html>