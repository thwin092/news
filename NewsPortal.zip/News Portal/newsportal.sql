-- phpMyAdmin SQL Dump
-- version 4.9.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 04, 2020 at 03:11 PM
-- Server version: 5.7.26
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `newsportal`
--

-- --------------------------------------------------------

--
-- Table structure for table `announcement`
--

CREATE TABLE `announcement` (
  `id` int(11) NOT NULL,
  `CategoryID` int(11) NOT NULL,
  `startdate` varchar(250) NOT NULL,
  `enddate` varchar(250) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `announcement`
--

INSERT INTO `announcement` (`id`, `CategoryID`, `startdate`, `enddate`, `status`) VALUES
(1, 3, '2020-11-04', '2020-11-25', 0),
(2, 3, '2020-11-03', '2020-11-25', 1),
(3, 3, '2020-11-03', '2021-03-01', 1),
(4, 12, 'mid', 'fdfd', 1),
(5, 3, '2020-11-04', '2020-11-25', 1);

-- --------------------------------------------------------

--
-- Table structure for table `marketingcoordinator`
--

CREATE TABLE `marketingcoordinator` (
  `coordinatorid` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `coordinatorname` varchar(250) NOT NULL,
  `coordinatoremail` varchar(250) NOT NULL,
  `username` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `phno` varchar(250) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `marketingcoordinator`
--

INSERT INTO `marketingcoordinator` (`coordinatorid`, `id`, `coordinatorname`, `coordinatoremail`, `username`, `password`, `phno`, `status`) VALUES
(17, 3, 'KO Ko', 'coordinator1@gmail.com', 'thwin', '123', '093366328', 1),
(18, 5, 'Ma Ma ', 'coordinator2@gmail.com', 'lopl', '123', '0924648383', 1),
(19, 2, 'Jasmine', 'coordinator3@gmail.com', 'jasmine', '123', '002992839', 1),
(20, 7, 'Hla Hla', 'coordinator4@gmail.com', 'hlahla', '123', '093478489', 1);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `studentid` int(11) NOT NULL,
  `studentname` varchar(255) NOT NULL,
  `CategoryName` varchar(250) NOT NULL,
  `studentemail` varchar(255) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phno` varchar(20) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`studentid`, `studentname`, `CategoryName`, `studentemail`, `username`, `password`, `phno`, `status`) VALUES
(3, 'Ta Khin Gyi', 'Technology', 'student1@gmail.com', 'fdsknidfs', '123', '32-40-34', 1),
(4, 'Mo Mo', 'Business', 'student2@gmail.com', 'lop', '123', '0393944', 1),
(5, 'John Smitt', 'Finance', 'student3@gmail.com', 'thwin1', '123', '004949493', 1),
(6, 'Thar Sit', 'Business', 'terjkrtkjb@gmail.com', 'thwin', 'Koko', '0983459', 1),
(8, 'Ba Sai', 'Software Enginnering', 'fdsjkjk@gmail.com', 'fdsjnvdfs', 'fsdjkbjksfd', '24332423', 1),
(9, 'Ngwe Pu', 'Software Enginnering', 'werknjkm@gmail.com', 'fddf', 'fgdgfd', '324324', 1),
(10, 'Terry Smith', 'Entertainment', 'student4@gmail.com', 'terrysmith', '123', '0943849383', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `id` int(11) NOT NULL,
  `AdminUserName` varchar(255) NOT NULL,
  `AdminPassword` varchar(255) NOT NULL,
  `AdminEmailId` varchar(255) NOT NULL,
  `Is_Active` int(11) NOT NULL,
  `CreationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`id`, `AdminUserName`, `AdminPassword`, `AdminEmailId`, `Is_Active`, `CreationDate`, `UpdationDate`) VALUES
(1, 'admin', '$2y$12$i4LMfeFPQpGSNPTaccIkKuwxAkJ4PhBr3JND7FpXwWFjRvchQn17C', 'thwinphyoaung@gmail.com', 1, '2020-05-27 17:51:00', '2020-10-24 18:21:07');

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--

CREATE TABLE `tblcategory` (
  `id` int(11) NOT NULL,
  `CategoryName` varchar(200) DEFAULT NULL,
  `Description` mediumtext,
  `PostingDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `Is_Active` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcategory`
--

INSERT INTO `tblcategory` (`id`, `CategoryName`, `Description`, `PostingDate`, `UpdationDate`, `Is_Active`) VALUES
(2, 'Software Enginnering', 'about software ', '2018-06-06 10:28:09', '2020-11-01 15:04:33', 1),
(3, 'Finance', 'Related to business', '2018-06-06 10:35:09', '2020-11-03 20:19:05', 1),
(5, 'Entertainment', 'Entertainment related  News', '2018-06-14 05:32:58', '2018-06-14 05:33:41', 1),
(7, 'Business', 'Business', '2018-06-22 15:46:22', '0000-00-00 00:00:00', 1),
(11, 'Technology', 'about technology', '2020-11-01 15:03:28', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblcomments`
--

CREATE TABLE `tblcomments` (
  `id` int(11) NOT NULL,
  `postId` char(11) DEFAULT NULL,
  `name` varchar(120) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `comment` mediumtext,
  `postingDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcomments`
--

INSERT INTO `tblcomments` (`id`, `postId`, `name`, `email`, `comment`, `postingDate`, `status`) VALUES
(1, '12', 'Anuj', 'anuj@gmail.com', 'Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis.', '2018-11-21 11:06:22', 0),
(2, '12', 'Test user', 'test@gmail.com', 'This is sample text for testing.', '2018-11-21 11:25:56', 1),
(3, '7', 'ABC', 'abc@test.com', 'This is sample text for testing.', '2018-11-21 11:27:06', 1),
(4, '35', 'motherfucker', 'minmay@gmail.com', 'a', '2020-10-29 10:18:17', 0),
(5, '30', 'sfsf', 'fssdm@gmail.com', 'a', '2020-10-29 10:21:12', 1),
(6, '13', 'sfjnsfd', 'fdsjkbfs@gmail.com', 'sfvbhjfs', '2020-10-29 12:24:44', 1),
(7, '31', 'bbj', 'dsfmnk@gmail.com', 'fdsmnsd', '2020-10-29 12:52:18', 1),
(8, '7', 'fsfd', 'fssf2@gmail.com', 'fsdfsd', '2020-10-30 16:36:47', 1),
(9, '16', 'kjjkgf', 'gfkjnjk@gmail.com', 'dsfd', '2020-11-01 07:38:30', 1),
(10, '27', 'Ma Ma', 'thwin1@gmail.com', 'Good', '2020-11-01 14:40:35', 1),
(11, '28', 'fsknksf', 'sfdknkdsf@gmail.com', 'sfdknoioefs', '2020-11-03 03:51:37', 1),
(12, '28', 'ewhgiuwe', 'fsjkij@gmail.com', 'dsnjksdf', '2020-11-03 03:55:03', 1),
(13, '28', 'fdgknkfd', 'fdgklok@gmail.com', 'fdggfd', '2020-11-03 03:56:37', 1),
(14, '43', 'KO KO', 'thwin289@gmail.com', 'Nice ariticle', '2020-11-04 07:26:42', 1),
(15, '43', 'KO Ko', 'thwin0388@gmail.com', 'Nice', '2020-11-04 07:55:25', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblpages`
--

CREATE TABLE `tblpages` (
  `id` int(11) NOT NULL,
  `PageName` varchar(200) DEFAULT NULL,
  `PageTitle` mediumtext,
  `Description` longtext,
  `PostingDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpages`
--

INSERT INTO `tblpages` (`id`, `PageName`, `PageTitle`, `Description`, `PostingDate`, `UpdationDate`) VALUES
(1, 'aboutus', 'About News Portal', '<font color=\"#7b8898\" face=\"Mercury SSm A, Mercury SSm B, Georgia, Times, Times New Roman, Microsoft YaHei New, Microsoft Yahei, å¾®è½¯é›…é»‘, å®‹ä½“, SimSun, STXihei, åŽæ–‡ç»†é»‘, serif\"><span style=\"font-size: 26px;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</span></font><br>', '2018-06-30 18:01:03', '2018-06-30 19:19:51'),
(2, 'contactus', 'Contact Details', '<p><br></p><p><br></p>', '2018-06-30 18:01:36', '2020-11-01 12:33:09');

-- --------------------------------------------------------

--
-- Table structure for table `tblposts`
--

CREATE TABLE `tblposts` (
  `id` int(11) NOT NULL,
  `studentid` int(11) NOT NULL,
  `studentname` varchar(250) NOT NULL,
  `PostTitle` longtext,
  `CategoryId` int(11) DEFAULT NULL,
  `coordinatorid` int(11) NOT NULL,
  `PostDetails` longtext CHARACTER SET utf8,
  `PostingDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `Is_Active` int(1) DEFAULT NULL,
  `PostUrl` mediumtext,
  `PostImage` varchar(255) DEFAULT NULL,
  `Postfile` varchar(250) NOT NULL,
  `size` int(11) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblposts`
--

INSERT INTO `tblposts` (`id`, `studentid`, `studentname`, `PostTitle`, `CategoryId`, `coordinatorid`, `PostDetails`, `PostingDate`, `UpdationDate`, `Is_Active`, `PostUrl`, `PostImage`, `Postfile`, `size`, `status`) VALUES
(40, 3, 'Ta Khin Gyi', 'National Geographic', 5, 18, '<p><span style=\"caret-color: rgb(77, 81, 86); color: rgb(77, 81, 86); font-family: arial, &quot;Noto Sans Myanmar UI&quot;, sans-serif;\">National Geographic is the official magazine of the National Geographic Society. It has been published continuously since its first issue in 1888, nine months after the Society itself was founded. It primarily contains articles about science, geography, history, and world culture&nbsp;</span><a href=\"https://www.nationalgeographic.com\">https://www.nationalgeographic.com</a><br></p>', '2020-11-04 06:07:31', '2020-11-04 06:08:15', 1, 'National-Geographic', 'seo.ngsversion.1565614141405.jpg', 'nlks.pdf', 249342, 0),
(41, 3, 'Ta Khin Gyi', 'Top Finance  Magazine', 3, 17, '<p><span style=\"caret-color: rgb(76, 76, 76); color: rgb(76, 76, 76); font-family: Roboto, Arial, Helvetica, sans-serif;\"><b>Arguably the most famous American business magazine, Forbes is read by all manor of professionals for updated news, especially pertaining to business and finance.</b></span><br></p>', '2020-11-04 06:14:03', '2020-11-04 06:24:47', 1, 'Top-Finance--Magazine', '4ABig.jpg', 'bal.pdf', 267704, 0),
(42, 4, 'Mo Mo', 'Top 10 software engineering', 2, 19, '<p><span style=\"caret-color: rgb(51, 51, 51); color: rgb(51, 51, 51); font-family: Arial, &quot;Microsoft yahei&quot;, Verdana, 宋体, &quot;Hiragino Sans GB&quot;, &quot;冬青黑体简体中文 w3&quot;, &quot;Microsoft Yahei&quot;, STXihei, 华文细黑, 微软雅黑, SimSun, Heiti, 黑体, sans-serif; word-spacing: 1px;\">Proven techniques for software engineering success This in-depth volume examines software engineering topics that are not covered elsewhere: the question of why software engineering has developed more than 2,500 programming languages; problems with traditional definitions of software quality; and problems with common metrics, \"lines of code,\" and \"cost per defect\" that violate standard economic assumptions. The book notes that a majority of \"new\" projects are actually replacements for legacy applications, illustrating that data mining for lost requirements should be a standard practice. Difficult social engineering issues are also covered, such as how to minimize harm from layoffs and downsizing. Software Engineering Best Practices explains how to effectively plan, size, schedule, and manage software projects of all types, using solid engineering procedures. It details proven methods, from initial requirements through 20 years of maintenance. Portions of the book have been extensively reviewed by key engineers from top companies, including IBM, Microsoft, Unisys, and Sony. Manage Agile, hierarchical, matrix, and virtual software development teams Optimize software quality using JAD, OFD, TSP, static analysis, inspections, and other methods with proven success records Use high-speed functional metrics to assess productivity and quality levels Plan optimal organization, from small teams through more than 1,000 personnel</span><br></p>', '2020-11-04 06:21:15', '2020-11-04 06:26:56', 1, 'Top-10-software-engineering', '1428490.jpg', 'nlks (1).pdf', 249342, 0),
(43, 10, 'Terry Smith', 'Top 10 Ariticles', 3, 17, '<p>these are the top ariticle</p>', '2020-11-04 07:11:24', '2020-11-04 07:54:33', 1, 'Top-10-Ariticles', 'engineering.jpg', 'nlks (1) (1).pdf', 261400, 0),
(44, 10, 'Terry Smith', 'soijiwere', 3, 17, '<p>ewrklnerwkner</p>', '2020-11-04 07:20:00', NULL, 0, 'soijiwere', 'engineering.jpg', 'nlks (1) (1).pdf', 261400, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `announcement`
--
ALTER TABLE `announcement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `marketingcoordinator`
--
ALTER TABLE `marketingcoordinator`
  ADD PRIMARY KEY (`coordinatorid`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`studentid`);

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcategory`
--
ALTER TABLE `tblcategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcomments`
--
ALTER TABLE `tblcomments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblpages`
--
ALTER TABLE `tblpages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblposts`
--
ALTER TABLE `tblposts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `announcement`
--
ALTER TABLE `announcement`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `marketingcoordinator`
--
ALTER TABLE `marketingcoordinator`
  MODIFY `coordinatorid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `studentid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblcategory`
--
ALTER TABLE `tblcategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tblcomments`
--
ALTER TABLE `tblcomments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tblpages`
--
ALTER TABLE `tblpages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblposts`
--
ALTER TABLE `tblposts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;
